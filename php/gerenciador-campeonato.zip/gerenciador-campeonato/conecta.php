<?php
    $servername = "127.0.0.1";
    $username = "root";
    $password = "Canddoce18906";
    $dbname = "db_campeonato";
    $connection = mysqli_connect($servername, $username, $password, $dbname);
    if ($connection->connect_error) {
        die("Connection failed: " . $connection->connect_error);
    }
?>