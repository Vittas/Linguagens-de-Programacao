intervalos = []
for _ in range(int(input())):
    entrada = input().split(' ')
    entrada[0] = entrada[0].replace("-", "")
    entrada[1] = entrada[1].replace("-", "")
    cepInicio, cepFinal = list(map(int, entrada))
    intervalos.append([cepInicio, cepFinal])
for _ in range(int(input())):
    cepCliente = input()
    cepClienteFormatado = int(cepCliente.replace("-", ""))
    for i in intervalos:
        cepInicio = i[0]
        cepFinal = i[1]
        if cepInicio <= cepClienteFormatado <= cepFinal:
            print(f"{cepCliente} is serverd by delivery system.")
        elif cepInicio > cepClienteFormatado or cepFinal < cepClienteFormatado:
            print(f"{cepCliente} is not serverd by delivery system.")