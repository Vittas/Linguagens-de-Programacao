lista = []
numero = int(input())
contador = 1
while contador <= numero:
    if contador%4 == 0:
        lista.append("pim")
    else:
        lista.append(str(contador))
    contador += 1
print(" ".join(lista))
