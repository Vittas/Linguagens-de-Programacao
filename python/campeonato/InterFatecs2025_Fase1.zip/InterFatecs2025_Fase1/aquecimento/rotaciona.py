# import math
numero, anguloInicial = map(int, input().split())
# math.
for _ in range(numero):
    x, y = map(int, input().split())