def primo(numero):
    contador = 0
    for i in range(numero):
        if numero%(i+1) == 0:
            contador += 1
    return contador
entrada = int(input())
if primo(entrada) == 3:
    print("sim")
else:
    print("nao")