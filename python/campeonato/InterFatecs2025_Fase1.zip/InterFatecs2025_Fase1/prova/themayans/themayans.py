dicio = {"." : 1, "-": 5, "*": 0}

while True:
    traduzidoDecimalConjunto = []
    listanumero = input()

    if listanumero == "*":
        print(0)
        break
    
    listanumero = map(list, listanumero.split())
    
    for i in listanumero:
        traduzidoDecimal = []
        for j in i:
            traduzidoDecimal.append(dicio[j])
        traduzidoDecimalConjunto.append(sum(traduzidoDecimal))
    listaCoeficientePosicao = []
    for i in range(len(traduzidoDecimalConjunto)):
        listaCoeficientePosicao.append(20**i)
    listaCoeficientePosicao.sort(reverse=True)
    # print(listaCoeficientePosicao)
    # print(traduzidoDecimalConjunto)
    total = 0
    for i in range(len(listaCoeficientePosicao)):
        total += listaCoeficientePosicao[i]*traduzidoDecimalConjunto[i]
    print(total)

        