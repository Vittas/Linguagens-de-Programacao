tempo = int(input())
nVale = int(input())
nColina = int(input())
nTopo = int(input())

tempo *= 2

fVale = nColina * tempo + (nTopo * tempo) * 2
fColina= nVale * tempo + nTopo * tempo
fTopo = nColina * tempo + (nVale * tempo) * 2

tempos = [fVale, fColina, fTopo]

print(min(tempos))