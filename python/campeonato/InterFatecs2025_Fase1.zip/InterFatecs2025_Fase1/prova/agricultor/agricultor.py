numeroDeConjunto = int(input())

for _ in  range(numeroDeConjunto):
    temperaturaCelcius, UmidadeSolo, previsaoChuva = map(float, input().split())

    previsaoChuva = bool(previsaoChuva)

    if previsaoChuva:
        print("NAO REGAR")
    else:
        if temperaturaCelcius > 30 and UmidadeSolo < 50:
            print("REGAR")
        else:
            print("NAO REGAR")
