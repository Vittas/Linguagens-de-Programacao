posto1, demora1 = map(int, input().split())
posto2, demora2 = map(int, input().split())

for i in range(1, 5001):
    if (i + posto1) % demora1 == 0 and (i + posto2) % demora2 == 0:
        print(i)
        break
