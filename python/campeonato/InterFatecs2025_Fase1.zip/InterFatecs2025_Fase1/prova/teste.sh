DESAFIO=$1

cd "$DESAFIO" || exit

echo "=== PREPARANDO AMBIENTE ==="
mkdir -p result
rm -f result/*.txt

echo -e "\n=== VERIFICANDO ARQUIVOS ==="
echo "Arquivo Python principal: $(ls *.py)"
echo "Casos de teste: $(ls input/*.txt | wc -l) entradas e $(ls output/*.txt | wc -l) saídas esperadas"

echo -e "\n=== EXECUTANDO TESTES ==="
start_time=$SECONDS

for input_file in $(ls input/*.txt | sort -V); do
    numero=$(basename "$input_file" .txt)
    echo "-> Testando caso ${numero}..."
    
    python3 "${DESAFIO}.py" < "input/${numero}.txt" > "result/${numero}.txt"
    
    if [[ $? -ne 0 ]]; then
        echo "ERRO na execução para o caso ${numero}!"
    fi
done

elapsed=$((SECONDS - start_time))
echo -e "\nTempo total de execução: ${elapsed} segundos"

echo -e "\n=== VALIDANDO RESULTADOS ==="
erros=0

for output_file in $(ls output/*.txt | sort -V); do
    numero=$(basename "$output_file" .txt)
    
    if [[ ! -f "result/${numero}.txt" ]]; then
        echo "ERRO: Arquivo result/${numero}.txt não foi gerado!"
        ((erros++))
        continue
    fi
    
    diff -q "output/${numero}.txt" "result/${numero}.txt" >/dev/null
    
    if [[ $? -eq 0 ]]; then
        echo "✓ Caso ${numero} correto!"
    else
        echo "✗ Caso ${numero} incorreto!"
        ((erros++))
    fi
done

echo -e "\n=== RELATÓRIO FINAL ==="
if [[ $erros -eq 0 ]]; then
    echo "Todos os testes passaram!"
else
    echo "${erros} testes falharam!"
fi

exit $erros