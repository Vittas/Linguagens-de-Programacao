tecido = int(input())
camisetas = []
for _ in range(3):
    custoTecido, lucro = map(int, input().split())
    camisetas.append([custoTecido, lucro])
lucroMaximo = [0] * (tecido + 1)
print(lucroMaximo)
for i in range(1, tecido + 1):
    for j, k in camisetas:
        print(j)
        print(k)
        if i >= j:
            lucroMaximo[i] = max(lucroMaximo[i], lucroMaximo[i - j] + k)
print(lucroMaximo[tecido])