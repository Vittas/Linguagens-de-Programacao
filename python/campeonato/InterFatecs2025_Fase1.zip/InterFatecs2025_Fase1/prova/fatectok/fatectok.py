RelacoesNomes = []

for i in range(int(input())):
    nome1, nome2 = map(str, input().split(" "))
    listaNome = [nome1, [nome2]]
    if len(RelacoesNomes) > 0:
        for x in RelacoesNomes:
            if x[0] == nome1:
                x[1].append(nome2)
            else:
                RelacoesNomes.append(listaNome)
    else:
        RelacoesNomes.append(listaNome)

input()

# print(RelacoesNomes)

while True:

    nome1, nome2 = map(str, input().split(" "))
    
    if nome1 == "*" and nome2=="*":
        break

    for x in RelacoesNomes:
        if x[0] == nome1:
            # print(x[1])
            # for nomes in x[1]:
            resposta = []
            #     print(x[1].count(nome2))

            if x[1].count(nome2) > 0:
            #         print(x[1].count(nome2))
            #     # if nome2 == nomes:
            #     #     # print(x[1].index(nome2))
                resposta.append(f'{nome1}-{nome2} = {x[1].index(nome2)+1}')
                break
            else:
                resposta.append(f'{nome1}-{nome2} = sem conexao')
                break
    print(resposta[0])   




