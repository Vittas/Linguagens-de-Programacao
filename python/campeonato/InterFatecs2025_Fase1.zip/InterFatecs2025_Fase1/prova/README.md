# InterFatecs 2025 - Primeira Fase
- [ ] Aquecimento

- [X] A themayans
- [ ] B scoreboard
- [X] C agricultor
- [ ] D helicon
- [X] E triangulo
- [X] F suprimentos
- [X] G base
- [ ] H fatectok
- [X] I anonnavai
- [ ] J camisetas
- [X] K fonte
