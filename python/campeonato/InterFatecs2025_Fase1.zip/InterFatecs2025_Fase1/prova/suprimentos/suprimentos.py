saldo = 0
min_saldo = 0
for _ in range(int(input())):
    recurso = int(input())
    saldo += recurso
    min_saldo = min(min_saldo, saldo)
print(abs(min_saldo))
