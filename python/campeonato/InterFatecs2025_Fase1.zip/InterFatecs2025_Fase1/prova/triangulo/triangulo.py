import math
pi = 3.1415
while True:
    entrada = input()
    if entrada == "0 0 0":
        break
    a, b, theta = map(float, entrada.split())
    area = (a * (b * math.sin(theta * (pi / 180.0))))/2
    print(f"{area:.4f}")
