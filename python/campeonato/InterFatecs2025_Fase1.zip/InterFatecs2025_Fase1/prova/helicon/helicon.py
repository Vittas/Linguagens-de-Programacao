def maior_soma_subsequencia(N, A):
    max_soma = float('-inf')

    for k in range(1, N // 2 + 1):
        for i in range(k):
            soma_atual = float('-inf')
            soma_temp = 0
            j = i
            while j < N:
                soma_temp += A[j]
                soma_atual = max(soma_atual, soma_temp)
                if soma_temp < 0:
                    soma_temp = 0
                j += k
            max_soma = max(max_soma, soma_atual)

    return max_soma

# Leitura da entrada
N = int(input())
A = list(map(int, input().split()))

# Cálculo e saída
print
